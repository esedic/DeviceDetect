DeviceDetect
============

Device Detector plugin for Joomla 2.5 makes it easy to write conditional CSS and/or JavaScript based on device operating system (iOS, Android, Blackberry, Windows), orientation (Portrait vs. Landscape), and type (Tablet vs. Mobile). Based on script from Matthew Hudson: <a href="https://github.com/matthewhudson/device.js/">github.com/matthewhudson/device.js</a>.
